import React from 'react';
import { Link } from 'react-router-dom';
import { AuthUserContext } from '../Session';
//import SignOutButton from '../SignOut';
import * as ROUTES from '../../constants/routes';
import * as ROLES from '../../constants/roles';
import logoscreen from "../img/plus.png";
import './style.css';


const Navigation = () => (
  <AuthUserContext.Consumer>
    {authUser =>
      authUser ? (
        <NavigationAuth authUser={authUser} />
      ) : (
        <NavigationNonAuth />
      )
    }
  </AuthUserContext.Consumer>
);

const NavigationAuth = ({ authUser }) => (
    <div className='manusup'>
      <button className='btnbar'>
      <Link to={ROUTES.ACCOUNT} className='textbtnbar'>
      <img src="https://img.icons8.com/pastel-glyph/64/null/gender-neutral-user.png"/>
        </Link>
      </button>
      <button className='btnbar'>
      <Link to={ROUTES.IDIOMA} className='textbtnbar'>
          <img src="https://img.icons8.com/dotty/80/null/language.png"/>
        </Link>
      </button>
     
      <button className='btnbar'>
        <Link to={ROUTES.FINANCAS} className='textbtnbar'>
        <img src="https://img.icons8.com/dotty/80/null/money-yours.png" />
        </Link>
      </button>
      <button className='btnbar'>
      <Link to={ROUTES.NUTRICAO} className='textbtnbar'>
      <img src="https://img.icons8.com/dotty/80/null/food.png"/>
        </Link>
      </button>
    {!!authUser.roles[ROLES.ADMIN] && (
      <button className='btnbar'>
        <Link to={ROUTES.ADMIN} className='textbtnbar'>
        <img src="https://img.icons8.com/ios/50/null/mechanistic-analysis.png"/>
        </Link>
      </button>
    )}
   </div>
);

const NavigationNonAuth = () => (
    
  <div className='menuexterno'>
    <div className='logscreen'><img src={logoscreen} alt=""/>
    <div className='navegscreen'>
      <div className='btnexterno'>Sobre</div>
      <div className='btnexterno'>Visto-Passaporte</div>
      <div className='btnexterno'>Faculdades</div>
      <div className='btnexterno'>Franquia</div>
    </div>
    </div>



    <button className='btnselectvgo'>
      <Link to={ROUTES.SELETIVA} className='textbutonemail'>
        Incrição para seletiva
      </Link>
    </button>

    <button className='btnloggoogleinto'>
        <Link to={ROUTES.SIGN_IN} className='textbutongoogle'>
          Entrar 
        </Link>
    </button>



  </div>
);

export default Navigation;
