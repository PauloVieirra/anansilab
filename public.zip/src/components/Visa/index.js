import React from 'react';

export default function Visa() {
 return (
       <div>Visto</div>
  );
}