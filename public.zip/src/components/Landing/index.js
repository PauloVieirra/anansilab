import React from 'react';
import './style.css';
import logo from "../img/plus.png";
import { Link } from 'react-router-dom';
import * as ROUTES from '../../constants/routes';
import * as ROLES from '../../constants/roles';
import backgroundmobi from "../img/fundomobile.png"




const Landing = () => (
  <div className='maininto'>
      <div className='divbackground'> 
       
      </div>
      <div className='divsupinto'>
      <div className='divimglogoini'> <img src={logo} className='imglogo'/> </div>
      </div>
      <div className='divslider'>
      1234156
      <div className='divterm'>
      <Link to={ROUTES.TERMOS} className='textbutonterms'>
          Termos de uso e privacidade 
        </Link>
        </div>
      </div>

    






     
      
  </div>
);

export default Landing;
