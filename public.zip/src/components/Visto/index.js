import React from 'react';

export default function Visto() {
 return (
   <div>Visto</div>
  );
}