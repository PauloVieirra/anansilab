import React from 'react';

export default function Financas() {
 return (
       <div>Financas</div>
  );
}