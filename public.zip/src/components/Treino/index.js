import React from 'react';

export default function Treino() {
 return (
 <div>Treinos</div>
  );
}