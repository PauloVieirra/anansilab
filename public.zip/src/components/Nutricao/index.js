import React from 'react';

export default function Nutricao() {
 return (
   <div>Nutri</div>
  );
}