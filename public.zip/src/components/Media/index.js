import React from 'react';

export default function Media() {
 return (
   <div>Media</div>
  );
}