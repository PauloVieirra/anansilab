import React from 'react';

export default function Franquia() {
 return (
   <div>Franquia</div>
  );
}