import React from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';

import Navigation from '../Navigation';
import LandingPage from '../Landing';
import SignUpPage from '../SignUp';
import SignInPage from '../SignIn';
import PasswordForgetPage from '../PasswordForget';
import HomePage from '../Home';
import AccountPage from '../Account';
import AdminPage from '../Admin';
import Termos from '../Termos';
import Seletiva from '../Seletiva';
import Franquia from '../Franquia';
import Sobre from '../Sobre';
import Visto from '../Visto';
import Visa from '../Visa';
import Treino from '../Treino';
import Media from '../Media';
import Financas from '../Financas';
import Nutricao from '../Nutricao';
import Idioma from '../Idioma';
import Faculdade from '../Faculdade';


import * as ROUTES from '../../constants/routes';
import { withAuthentication } from '../Session';

const App = () => (
  <Router>
    <div>
      <Navigation />

    

      <Route exact path={ROUTES.LANDING} component={LandingPage} />
      <Route path={ROUTES.SIGN_UP} component={SignUpPage} />
      <Route path={ROUTES.SIGN_IN} component={SignInPage} />
      <Route path={ROUTES.TERMOS} component={Termos}/>
      <Route path={ROUTES.SELETIVA} component={Seletiva}/>
      <Route path={ROUTES.FRANQUIA} component={Franquia}/>
      <Route path={ROUTES.VISTO} component={Visto}/>
      <Route path={ROUTES.FINANCAS} component={Financas}/>
      <Route path={ROUTES.IDIOMA} component={Idioma}/>
      <Route path={ROUTES.MEDIA} component={Media}/>
      <Route path={ROUTES.NUTRICAO} component={Nutricao}/>
      <Route path={ROUTES.FACULDADE} component={Faculdade}/>
      <Route path={ROUTES.SOBRE} component={Sobre}/>
      <Route path={ROUTES.PASSWORD_FORGET} component={PasswordForgetPage} />
      <Route path={ROUTES.ACCOUNT} component={AccountPage} />
      <Route path={ROUTES.HOME} component={HomePage} />


      <Route path={ROUTES.ADMIN} component={AdminPage} />
      
    </div>
  </Router>
);

export default withAuthentication(App);
