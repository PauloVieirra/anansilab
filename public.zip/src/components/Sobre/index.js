import React from 'react';

export default function Sobre() {
 return (
   <div>Sobre</div>
  );
}