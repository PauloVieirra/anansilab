import React from 'react';
import './style.css';
import { Link } from 'react-router-dom';
import * as ROUTES from '../../constants/routes';
import logo from '../../components/img/plus.png';
import iconback from '../../components/img/arrow.png';

export default function Seletiva() {
 return (
   <div className='divseltiva'>
    <div className='divtopseletiv'>
        <div className='divsupseletiv'>
        <div className='divimglogoini'> <img src={logo} className='imglogo'/> </div>
        <div className='divbackselectiv'>
            <Link to={ROUTES.LANDING}> <img src={iconback} className='diviconback'/>    </Link>
        </div>
        </div>
    </div>
    <div className='divcrudseletiva'>
          <input
          name="email"
          type="text"
          placeholder="Nome completo"
          className='inputselet'
        />
        <input
          name="password"
          type="text"
          placeholder="Data de nascimento"
          className='inputselet'
        />
         <input
          name="password"
          type="text"
          placeholder="Estatura"
          className='inputselet'
        />
         <input
          name="password"
          type="text"
          placeholder="Peso"
          className='inputselet'
        />
         <input
          name="password"
          type="text"
          placeholder="Posição que joga"
          className='inputselet'
        />
         <input
          name="password"
          type="text"
          placeholder="Objetivo"
          className='inputselet'
        />
         <input
          name="password"
          type="text"
          placeholder="Telefone"
          className='inputselet'
        />
         <input
          name="password"
          type="text"
          placeholder="Email"
          className='inputselet'
        />
          <button className='btnselectsend'>
            Enviar
          </button>
          </div>
        
    </div>

       
  );
}