import React from 'react';

export default function Faculdade() {
 return (
   <div>Faculdade</div>
  );
}