import React, { Component } from 'react';
import { compose } from 'recompose';
import { Player } from 'video-react';
import { AuthUserContext } from '../Session';
import './styles.css';




export default props => {
  return (
    <div className='playerclas'>
    <Player 
     
      responsive="true"
      playsInline
      fluid='false'
      width={'50%'}
      height={'50%'}
      poster="/assets/poster.png"
      src="https://media.w3.org/2010/05/sintel/trailer_hd.mp4"
    />
     </div>
  );
};